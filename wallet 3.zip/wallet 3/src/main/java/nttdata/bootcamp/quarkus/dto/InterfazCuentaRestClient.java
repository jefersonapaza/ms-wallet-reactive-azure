package nttdata.bootcamp.quarkus.dto;

import java.util.List;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;


@RegisterRestClient
@Path("/wallet")

public interface InterfazCuentaRestClient {

    @POST
    List<Operacion> enviar(Operacion operacion);
}


