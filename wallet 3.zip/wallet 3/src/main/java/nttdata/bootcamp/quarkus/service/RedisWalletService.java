package nttdata.bootcamp.quarkus.service;

public class RedisWalletService {



}
