package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.Cuenta;
import org.mongodb.model.Operacion;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;
import java.lang.String;
import java.math.BigDecimal;



@ApplicationScoped
public class CuentaService {




    @Inject
    ReactiveMongoClient mongoClient;
    Operacion operacion ;
    
    public Cuenta findAccount(List<Cuenta> listacuentas, String numerotarjeta) {

        Cuenta cuenta = listacuentas.stream().filter(x -> x.tarjetaAsociada1 == numerotarjeta || x.tarjetaAsociada2 == numerotarjeta).collect(Collectors.toList()).get(0);

        if(cuenta != null) {

            return cuenta;
        }

        return null;
    }

     

    public Cuenta procesar(Cuenta  cuenta,Operacion operacion) {

                Instant marca = Instant.now();
                String  nuevo = marca.toString();
                operacion.setFecha(nuevo);
                String cantidad = operacion.getMonto();
                String hacer = operacion.getCodOperacion;
                String   queda = (cuenta.getSaldoCuenta());
                BigDecimal queda1  = BigDecimal.valueOf(Double.valueOf(queda));
                BigDecimal cantidad1  = BigDecimal.valueOf(Double.valueOf(cantidad));
                BigDecimal saldo ;
                if (hacer.equals("DEPOSITO"))
                   {
                   saldo = queda1.add(cantidad1) ;
                   
                   }
                else{

                    if (hacer.equals("RETIRO"))
                     {
                       saldo = queda1.subtract(cantidad1);
                     }
                   }

             cuenta.setSaldoCuenta(saldo.toString);
             cuenta.setOperacion(operacion);

             return   cuenta ;

    
        }
    
    
    
    
    
    public Uni<List<Cuenta>> list() {

        return getCollection().find()
                .map(doc -> {
                    Cuenta cuenta = new Cuenta();
                    cuenta.setNumeroCuenta(doc.getString("numeroCuenta"));
                    cuenta.setTitular(doc.getString("titular"));
                    cuenta.setTipoDocumento(doc.getString("tipoDocumento"));
                    cuenta.setNumeroDocumento(doc.getString("numeroDocumento"));
                    cuenta.setSaldoCuenta(doc.getString("saldoCuenta"));
                    cuenta.setTarjetaAsociada1(doc.getString("tarjetaAsociada1"));
                    cuenta.setTarjetaAsociada2(doc.getString("tarjetaAsociada2"));
                    cuenta.setSede(doc.getString("sede"));
                    Object prueba = doc.get("operacion");

                    String prueba2 = prueba.toString();
                    int inicio = prueba2.indexOf("{{");
                    int fin = prueba2.indexOf("}}");
                    prueba2 = prueba2.substring(inicio+2,fin);
                    String[] partes = prueba2.split(",");

                    int ini1 = partes[0].indexOf("=");
                    int fi1 =partes[0].length()-1 ;
                    String descri = partes[0].substring(ini1 +1 ,fi1+1);

                    int ini2 = partes[1].indexOf("=");
                    int fi2 =partes[1].length()-1 ;
                    String cod = partes[1].substring(ini2 +1 ,fi2+1);

                    int ini3 = partes[2].indexOf("=");
                    int fi3 =partes[2].length()-1 ;
                    String fech = partes[2].substring(ini3 +1 ,fi3+1);

                    int ini4 = partes[3].indexOf("=");
                    int fi4 =partes[3].length()-1 ;
                    String mon = partes[3].substring(ini4 +1 ,fi4+1);
                    Operacion opera = new Operacion(cod,descri,fech,mon);
                    cuenta.setOperacion(opera);
                    return cuenta;

                }).collect().asList();



    }






    public Uni<Void> add(Cuenta cuenta) {
        Document document = new Document()
                .append("numeroCuenta", cuenta.getNumeroCuenta())
                .append("titular", cuenta.getTitular())
                .append("tipoDocumento",cuenta.getTipoDocumento())
                .append("numeroDocumento",cuenta.getNumeroDocumento())
                .append("saldoCuenta",cuenta.getSaldoCuenta())
                .append("tarjetaAsociada1",cuenta.getTarjetaAsociada1())
                .append("tarjetaAsociada2",cuenta.getTarjetaAsociada2())
                .append("sede", cuenta.getSede())
                .append("operacion",cuenta.getOperacion() );
        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }





    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("CUENTA");
    }
}
