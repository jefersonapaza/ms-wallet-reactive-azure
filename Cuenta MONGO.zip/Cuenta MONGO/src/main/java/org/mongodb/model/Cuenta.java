package org.mongodb.model;

import java.util.Objects;
public class Cuenta {

    public String  numeroCuenta;
    public String  titular ;
    public String  tipoDocumento;
    public String  numeroDocumento;
    public String  saldoCuenta;
    public String  tarjetaAsociada1;
    public String  tarjetaAsociada2;
    public String  sede ;
    public Operacion operacion;

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getSaldoCuenta() {
        return saldoCuenta;
    }

    public void setSaldoCuenta(String saldoCuenta) {
        this.saldoCuenta = saldoCuenta;
    }

    public String getTarjetaAsociada1() {
        return tarjetaAsociada1;
    }

    public void setTarjetaAsociada1(String tarjetaAsociada1) {
        this.tarjetaAsociada1 = tarjetaAsociada1;
    }

    public String getTarjetaAsociada2() {
        return tarjetaAsociada2;
    }

    public void setTarjetaAsociada2(String tarjetaAsociada2) {
        this.tarjetaAsociada2 = tarjetaAsociada2;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public Operacion getOperacion() {
        return operacion;
    }

    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }




}
