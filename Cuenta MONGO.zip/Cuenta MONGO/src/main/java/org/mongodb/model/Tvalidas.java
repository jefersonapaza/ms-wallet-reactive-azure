package org.mongodb.model;

import java.util.Objects;
public class Tvalidas{

    private Operacion operacionCuenta;

    public Operacion getOperacionCuenta() {
        return operacionCuenta;
    }

    public void setOperacionCuenta(Operacion operacionCuenta) {
        this.operacionCuenta = operacionCuenta;
    }

    public String  NumeroCuentaAsociada;
    public String  Titular ;
    public String  TipoDocumento;
    public String  NumeroDocumento;
    public String  NumeroTarjeta;

    public String getNumeroCuentaAsociada() {
        return NumeroCuentaAsociada;
    }

    public void setNumeroCuentaAsociada(String numeroCuentaAsociada) {
        NumeroCuentaAsociada = numeroCuentaAsociada;
    }

    public String getTitular() {
        return Titular;
    }

    public void setTitular(String titular) {
        Titular = titular;
    }

    public String getTipoDocumento() {
        return TipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        TipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return NumeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        NumeroDocumento = numeroDocumento;
    }

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public Tvalidas() {
    }






}
