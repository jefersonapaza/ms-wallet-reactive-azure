package org.mongodb.resource;

import io.smallrye.mutiny.Uni;
import org.mongodb.model.Cuenta;
import org.mongodb.model.Operacion;
import org.mongodb.service.CuentaService;


import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/cuenta")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CuentaResource {

 @Inject
 CuentaService cuentaService;
 @GET
 public Uni<List<Cuenta>> list() {
      return cuentaService.list();
                               }

 @Path("/wallet")
 @POST
   public Operacion  actualizawallet(Operacion  llega) {

          String  numerotarjeta = llega.getNumeroTarjeta; // Obtengo numero de tarjeta credito

          Uni<List<Cuenta>> tempo1 = cuentaService.list(); // Obtengo la lista de cuentas

          Cuenta cuenta2 = cuentaService.findAccount(tempo1 ,numerotarjeta) ; // encuentro la cuenta que corresponde a la tarjeta
          cuenta2  =  cuentaService.procesar( cuenta2,llega );  // proceso el nuevo saldo de la cuenta
          cuentaService.add(cuenta2) ;               //  persiste la actualizacion del saldo
          if (cuentaService.add(cuenta2)== true){
                
                     llega.setCodOperacion("OK");
                     llega.setMonto(cuenta2.getSaldoCuenta());
                     return llega;

                                              }
           else {                         
                     llega.setCodOperacion("ERROR");
                     return llega;
              
                  }



                                             }


 @POST
    public Uni<Response> add(Cuenta cuenta) {
        return cuentaService.add(cuenta)
                .onItem().transform(id -> URI.create("/cuenta/" + id))
                .onItem().transform(uri -> Response.created(uri).build());
                                          }







}
